module.exports = {
    'extends': '../../../.eslintrc.js',
    'parser': '@typescript-eslint/parser',
};
