export const GRID_SIZE = 20;
export const GRID_COUNT = 25;
export const HIGHLIGHT_COLOR = '#BE4B87';
export const BG_COLOR = '#FFFFFF';
export const SCALE = 2;
export const ISOMETRIC_SCALE = 0.8602
export const ROTATION_DEGREES = 30;
