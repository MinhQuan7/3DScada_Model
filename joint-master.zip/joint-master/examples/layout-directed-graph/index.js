import 'core-js/stable';
import 'regenerator-runtime/runtime';
import './src/directed-graph.mjs';

import './styles.scss';
