import './styles.scss';
import { init } from './src/app';

init();
