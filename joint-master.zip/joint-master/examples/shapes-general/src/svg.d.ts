declare module "*.svg" {
    const value: any;
    export default value;
}
