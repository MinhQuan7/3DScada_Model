import 'core-js/stable';
import 'regenerator-runtime/runtime';
import './styles.scss';
import { init } from './src/app';

init();
