import * as joint from '../../';

console.log('Point', new joint.g.Point());


